<!-- Spinner Start -->
<div id="spinner"
    class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
    <div class="spinner-border position-relative text-success" style="width: 6rem; height: 6rem;" role="status">
    </div>
    <img class="position-absolute top-50 start-50 translate-middle" src="{{ asset('favicon48x48.png') }}" alt="Logo"
        width="50" height="50">
    {{-- <i class="fa fa-laptop-code fa-2x text-success position-absolute top-50 start-50 translate-middle"></i> --}}
</div>
<!-- Spinner End -->
