
<?php $__env->startSection('Pages'); ?>
    <div class="container">
        <div class="row my-3">
            <div class="col-12">
                <h1 class="mb-3"><?php echo e($title); ?> "<?php echo e($post->title); ?>"</h1>
                <div class="mb-5">
                    <a href="/dashboard/informasi" class="btn btn-success"><span data-feather="arrow-left"></span>
                        Kembali</a>
                    <a href="/dashboard/informasi/<?php echo e($post->slug); ?>/edit" class="btn btn-warning"><span
                            data-feather="edit"></span>
                        Ubah</a>
                    <form action="/dashboard/informasi/<?php echo e($post->slug); ?>" method="POST" class="d-inline">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger"
                            onclick="return confirm('Apakah Anda yakin menghapus informasi dari <?php echo e($post->title); ?>?')"><span
                                data-feather="trash"></span> Hapus</button>
                    </form>
                </div>
                <?php if($post->image): ?>
                    <div style="max-height: 350px; overflow: hidden;">
                        <img src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="<?php echo e($post->category->name); ?>"
                            class="img-fluid">
                    </div>
                <?php else: ?>
                    <svg class="bd-placeholder-img card-img-top" width="100%" height="350"
                        xmlns="http://www.w3.org/2000/svg" role="img"
                        aria-label="Placeholder: <?php echo e($post->category->name); ?>" preserveAspectRatio="xMidYMid slice"
                        focusable="false">
                        <title><?php echo e($post->category->name); ?></title>
                        <rect width="100%" height="100%" fill="#868e96"></rect><text x="48%" y="50%" fill="#dee2e6"
                            dy=".3em"><?php echo e($post->category->name); ?></text>
                    </svg>
                <?php endif; ?>
                <article class="my-3 fs-5">
                    <?php echo $post->body; ?>

                </article>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.Layouts.Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 6\PROJECT_GALING\web_profile_desa\resources\views/Dashboard/Pages/Posts/Show.blade.php ENDPATH**/ ?>