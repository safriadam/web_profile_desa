
<?php $__env->startSection('Pages'); ?>
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn"
        style="background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(<?php echo e(asset('assets/img/header.jpg')); ?>) center center no-repeat; background-size: cover;"
        data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white animated slideInDown mb-3"><?php echo e($title); ?></h1>
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-center mb-5">
            <div class="col-md-8">
                <p>Oleh: <a href="/posts?author=<?php echo e($post->author->username); ?>"
                        class="text-decoration-none"><?php echo e($post->author->name); ?></a> di <a
                        href="/posts?category=<?php echo e($post->category->slug); ?>"
                        class="text-decoration-none"><?php echo e($post->category->name); ?></a></p>
                <?php if($post->image): ?>
                    <div>
                        <img src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="<?php echo e($post->category->name); ?>"
                            class="img-fluid">
                    </div>
                <?php else: ?>
                    <img src="https://source.unsplash.com/1200x400?<?php echo e($post->category->name); ?>"
                        alt="<?php echo e($post->category->name); ?>" class="img-fluid">
                <?php endif; ?>
                <article class="my-3 fs-5">
                    <?php echo $post->body; ?>

                </article>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Guest.Layouts.Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 6\PROJECT_GALING\web_profile_desa\resources\views/Guest/Post.blade.php ENDPATH**/ ?>