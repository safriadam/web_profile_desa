
<?php $__env->startSection('Pages'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Dashboard</h1>
    </div>
    <div class="text-center">
        <img src="<?php echo e(asset('favicon.png')); ?>" alt="" width="300" height="300">
        <h2>Selamat Datang di Panel Admin <?php echo e(auth()->user()->name); ?>!</h2>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.Layouts.Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 6\PROJECT_GALING\web_profile_desa\resources\views/Dashboard/Pages/Index.blade.php ENDPATH**/ ?>