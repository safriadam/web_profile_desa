
<?php $__env->startSection('Pages'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo e($title); ?></h1>
    </div>
    <div class="table-responsive col-12">
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th scope="col" class="text-center">No.</th>
                    <th scope="col" class="text-center">Nama Pengguna</th>
                    <th scope="col" class="text-center">Username</th>
                    <th scope="col" class="text-center">E-Mail</th>
                    <th scope="col" class="text-center">Role</th>
                    <th scope="col" class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($post->name); ?></td>
                        <td><?php echo e($post->username); ?></td>
                        <td><?php echo e($post->email); ?></td>
                        <td><?php echo e($post->is_admin ? 'Admin' : 'User'); ?></td>
                        <td class="text-end">
                            <a href="/dashboard/pengguna/<?php echo e($post->id); ?>/edit" class="badge bg-warning"><span
                                    data-feather="edit"></span></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.Layouts.Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 6\PROJECT_GALING\web_profile_desa\resources\views/Dashboard/Pages/Users/Index.blade.php ENDPATH**/ ?>