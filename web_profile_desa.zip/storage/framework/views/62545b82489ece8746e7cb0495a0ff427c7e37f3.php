<!-- Topbar Start -->

<!-- Topbar End -->


<!-- Brand & Contact Start -->

        
<!-- Brand & Contact End -->


<!-- Navbar Start -->
<nav class="navbar navbar-expand-lg bg-primary navbar-dark sticky-top py-lg-0 px-lg-5 wow fadeIn" data-wow-delay="0.1s">
    <div class="container-fluid">
        <a href="/" class="navbar-brand m-0 p-0">
            <div class="d-flex align-items-center">
                <img src="<?php echo e(asset('favicon48x48.png')); ?>" alt="Logo" width="50" height="50">
                <span>
                    <h3 class="fw-bold text-light m-0 d-inline-block ms-3">KECAMATAN GALING</h3>
                </span>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarCollapse">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="<?php echo e(url('/')); ?>" class="nav-link <?php echo e(Request::is('/') ? 'active' : ''); ?>">BERANDA</a>
                </li>
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle <?php echo e(Request::is('about', 'structure') ? 'active' : ''); ?>" data-bs-toggle="dropdown">PROFIL</a>
                    <ul class="dropdown-menu border-0 rounded-0 rounded-bottom m-0">
                        <li><a href="<?php echo e(url('/about')); ?>" class="dropdown-item">TENTANG KAMI</a></li>
                        <li><a href="<?php echo e(url('/sambutan')); ?>" class="dropdown-item">SAMBUTAN CAMAT</a></li>
                        <li><a href="<?php echo e(url('/structure')); ?>" class="dropdown-item">STRUKTUR ORGANISASI</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(url('/kegiatan')); ?>" class="nav-link <?php echo e(Request::is('kegiatan') ? 'active' : ''); ?>">KEGIATAN</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(url('/pengumuman')); ?>" class="nav-link <?php echo e(Request::is('pengumuman') ? 'active' : ''); ?>">PENGUMUMAN</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(url('/berita')); ?>" class="nav-link <?php echo e(Request::is('berita') ? 'active' : ''); ?>">BERITA</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Navbar End -->
<?php /**PATH D:\Semester 6\PROJECT_GALING\web_profile_desa\resources\views/Guest/Layouts/Partials/Header.blade.php ENDPATH**/ ?>