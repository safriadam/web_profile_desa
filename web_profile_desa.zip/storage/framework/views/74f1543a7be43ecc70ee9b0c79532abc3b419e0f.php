
<?php $__env->startSection('Pages'); ?>
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn"
        style="background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(<?php echo e(asset('assets/img/header.jpg')); ?>) center center no-repeat; background-size: cover;"
        data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white animated slideInDown mb-3"><?php echo e($title); ?></h1>
        </div>
    </div>
    <div class="container">
        <div class="card p-5">
            <h3>Visi</h3>
            <p class="fst-italic text-dark">"<?php echo e($visi->value ?? ''); ?>"</p>
        </div>

        <div class="card p-5 mt-5">
            <h3>Misi</h3>
            <ol>
                <?php $__currentLoopData = $misi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-dark"><?php echo e($item->value); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Guest.Layouts.Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 6\PROJECT_GALING\web_profile_desa\resources\views/Guest/About.blade.php ENDPATH**/ ?>