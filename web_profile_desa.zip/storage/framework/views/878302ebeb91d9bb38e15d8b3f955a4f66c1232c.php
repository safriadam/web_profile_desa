<!-- Spinner Start -->
<div id="spinner"
    class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
    <div class="spinner-border position-relative text-success" style="width: 6rem; height: 6rem;" role="status">
    </div>
    <img class="position-absolute top-50 start-50 translate-middle" src="<?php echo e(asset('favicon48x48.png')); ?>" alt="Logo"
        width="50" height="50">
    
</div>
<!-- Spinner End -->
<?php /**PATH D:\Semester 6\PROJECT_GALING\web_profile_desa\resources\views/Guest/Layouts/Partials/Spinner.blade.php ENDPATH**/ ?>