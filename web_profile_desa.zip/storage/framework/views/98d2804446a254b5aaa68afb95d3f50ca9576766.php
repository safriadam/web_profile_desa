
<?php $__env->startSection('Pages'); ?>
    <!-- Carousel Start -->
    <div class="container-fluid p-0 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div id="header-carousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#header-carousel" data-bs-slide-to="0" class="active" aria-current="true"
                    aria-label="Slide 1">
                    <img class="img-fluid" src="<?php echo e(asset('assets/img/gedung.jpeg')); ?>" alt="Image">
                </button>
                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" data-bs-target="#header-carousel" data-bs-slide-to="<?php echo e($loop->iteration); ?>"
                        aria-current="true" aria-label="Slide 2">
                        <img class="img-fluid" src="<?php echo e(asset('assets/slider/' . $item->nama_gambar)); ?>" alt="Image">
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="card-img" src="<?php echo e(asset('assets/img/gedung.jpeg')); ?>" alt="Image">
                    <div class="carousel-caption">
                        <div class="p-3" style="max-width: 900px;">
                            <h4 class="text-white text-uppercase mb-4 animated zoomIn">Selamat Datang di Website</h4>
                            <h1 class="display-1 text-white mb-0 animated zoomIn">KECAMATAN GALING
                            </h1>
                        </div>
                    </div>
                </div>
                <?php if($slider): ?>
                    <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item">
                            <img class="card-img" src="<?php echo e(asset('assets/slider/' . $item->nama_gambar)); ?>" alt="Image">
                            <div class="carousel-caption">
                                <div class="p-3" style="max-width: 900px;">
                                    <h4 class="text-white text-uppercase mb-4 animated zoomIn"><?php echo e($item->keterangan); ?></h4>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#header-carousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <!-- Carousel End -->

    <!-- Facts Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-4 d-flex justify-content-center">
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="fact-item bg-light rounded text-center h-100 p-5">
                        <i class="fa fa-certificate fa-4x text-primary mb-4"></i>
                        <h5 class="mb-3">Sejak Tahun</h5>
                        <h1 class="display-5 mb-0" data-toggle="counter-up">1953</h1>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="fact-item bg-light rounded text-center h-100 p-5">
                        <i class="fa fa-users-cog fa-4x text-primary mb-4"></i>
                        <h5 class="mb-3">Jumlah Desa</h5>
                        <h1 class="display-5 mb-0" data-toggle="counter-up">9</h1>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="fact-item bg-light rounded text-center h-100 p-5">
                        <i class="fa fa-users fa-4x text-primary mb-4"></i>
                        <h5 class="mb-3">Jumlah Penduduk</h5>
                        <h1 class="display-5 mb-0" data-toggle="counter-up">26002</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Facts End -->

    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="img-border">
                        <img class="img-fluid" src="<?php echo e(asset('assets/img/gurus.jpeg')); ?>" alt="">
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="h-100">
                        <h6 class="section-title bg-white text-start text-success pe-3">Tentang Kita</h6>
                        <h1 class="display-6 mb-4">Visi <span class="text-success">Misi</span> beserta Tujuan Kecamatan
                            Galing</h1>
                        <p>Visi : </p>
                        <p>"<?php echo e($visi->value ?? ''); ?>"</p>
                        <p>Misi : </p>
                        <?php if(!$misi->isEmpty()): ?>
                            <ol>
                                <?php $__currentLoopData = $misi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($item->value); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        <?php endif; ?>
                        <div class="d-flex align-items-center mb-4 pb-2">
                            <img class="flex-shrink-0 rounded-circle" src="<?php echo e(asset('assets/img/kepalaportrait.jpeg')); ?>"
                                alt="" style="width: 50px; height: 50px;">
                            <div class="ps-4">
                                <h6>SURIAWAN, S.ST., MT.</h6>
                                <small>Camat Galing</small>
                            </div>
                        </div>
                        <a class="btn btn-primary rounded-pill py-3 px-5" href="/about">Baca Selengkapnya</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

    <!-- Project Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <h6 class="section-title bg-white text-center text-success px-3">Kegiatan Kami</h6>
                <h1 class="display-6 mb-4">Kegiatan-Kegiatan di Kecamatan Galing</h1>
            </div>
            <div class="owl-carousel project-carousel wow fadeInUp" data-wow-delay="0.1s">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="project-item border rounded h-100 p-4" data-dot="<?php echo e($loop->iteration); ?>">
                        <div class="position-relative mb-4">
                            <img class="img-fluid rounded" src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="">
                            <a href="<?php echo e(asset('storage/' . $post->image)); ?>" data-lightbox="project"><i
                                    class="fa fa-eye fa-2x"></i></a>
                        </div>
                        <h6 class="text-center"><?php echo e($post->title); ?></h6>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </div>
    <!-- Project End -->

    <!-- Team Start -->
    
    <!-- Team End -->

    <!-- Service Start -->
    
    <!-- Service End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Guest.Layouts.Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 6\PROJECT_GALING\web_profile_desa\resources\views/Guest/Index.blade.php ENDPATH**/ ?>