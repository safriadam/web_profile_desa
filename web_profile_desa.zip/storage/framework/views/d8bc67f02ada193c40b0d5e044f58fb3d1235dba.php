<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>" aria-current="page"
                    href="<?php echo e(url('/dashboard')); ?>">
                    <span data-feather="home" class="align-text-bottom"></span>
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::is('dashboard/informasi*') ? 'active' : ''); ?>"
                    href="<?php echo e(url('/dashboard/informasi')); ?>">
                    <span data-feather="file-text" class="align-text-bottom"></span>
                    Informasi
                </a>
            </li>
        </ul>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                <span>ADMINISTRATOR</span>
            </h6>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('dashboard/publikasi*') ? 'active' : ''); ?>"
                        href="<?php echo e(url('/dashboard/publikasi')); ?>">
                        <span data-feather="external-link" class="align-text-bottom"></span>
                        Publikasi
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('dashboard/kategori*') ? 'active' : ''); ?>"
                        href="<?php echo e(url('/dashboard/kategori')); ?>">
                        <span data-feather="grid" class="align-text-bottom"></span>
                        Kategori
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('dashboard/pengguna*') ? 'active' : ''); ?>"
                        href="<?php echo e(url('/dashboard/pengguna')); ?>">
                        <span data-feather="users" class="align-text-bottom"></span>
                        Pengguna
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('/dashboard/slider*') ? 'active' : ''); ?>"
                        href="<?php echo e(url('/dashboard/slider')); ?>">
                        <span data-feather="image" class="align-text-bottom"></span>
                        Gambar Slider
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('/dashboard/visiMisi*') ? 'active' : ''); ?>"
                        href="<?php echo e(url('/dashboard/visiMisi')); ?>">
                        <span data-feather="target" class="align-text-bottom"></span>
                        Visi & Misi
                    </a>
                </li>
            </ul>
        <?php endif; ?>

        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>UTILITES</span>
        </h6>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::is('dashboard/profil*') ? 'active' : ''); ?>"
                    href="/dashboard/profil/<?php echo e(auth()->user()->id); ?>/edit">
                    <span data-feather="settings" class="align-text-bottom"></span>
                    Pengaturan
                </a>
            </li>
        </ul>

    </div>
</nav>
<?php /**PATH D:\Semester 6\PROJECT_GALING\web_profile_desa\resources\views/Dashboard/Layouts/Partials/Sidebar.blade.php ENDPATH**/ ?>