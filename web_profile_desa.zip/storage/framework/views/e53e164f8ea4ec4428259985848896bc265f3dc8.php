
<?php $__env->startSection('Pages'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo e($title); ?></h1>
        <a href="/dashboard/slider/create" class="badge bg-success"><span data-feather="plus"></span></a>
    </div>
    <div class="table-responsive col-12">
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th scope="col">Gambar</th>
                    <th scope="col">Keterangan</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <img src="<?php echo e(url('assets/slider/'. $item->nama_gambar)); ?>" style="max-width: 250px; width: 100%;">
                        </td>
                        <td><?php echo e($item->keterangan); ?></td>
                        <td>
                            <div class="d-flex">
                                
                                <a href="slider/delete/<?php echo e($item->id); ?>" class="btn btn-danger mx-2"><span data-feather="trash-2"></span></a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.Layouts.Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 6\PROJECT_GALING\web_profile_desa\resources\views/Dashboard/Pages/Slider/Index.blade.php ENDPATH**/ ?>