
<?php $__env->startSection('Pages'); ?>
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn"
        style="background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(<?php echo e(asset('assets/img/header.jpg')); ?>) center center no-repeat; background-size: cover;"
        data-wow-delay="0.1s">
        <div class="container text-center py-5">
            <h1 class="display-4 text-white animated slideInDown mb-3"><?php echo e($title); ?></h1>
        </div>
    </div>
    <div class="container wow fadeIn" data-wow-delay="0.1s">
        <?php if($posts->count()): ?>
            <div class="card mb-3">
                <?php if($posts[0]->image): ?>
                    <div style="max-height: 400px; overflow: hidden;">
                        <img src="<?php echo e(asset('storage/' . $posts[0]->image)); ?>" alt="<?php echo e($posts[0]->category->name); ?>"
                            class="img-fluid">
                    </div>
                <?php else: ?>
                    <svg class="bd-placeholder-img card-img-top" width="100%" height="400" xmlns="http://www.w3.org/2000/svg"
                        role="img" aria-label="Placeholder: <?php echo e($posts[0]->category->name); ?>"
                        preserveAspectRatio="xMidYMid slice" focusable="false">
                        <title><?php echo e($posts[0]->category->name); ?></title>
                        <rect width="100%" height="100%" fill="#868e96"></rect><text x="48%" y="50%" fill="#dee2e6"
                            dy=".3em"><?php echo e($posts[0]->category->name); ?></text>
                    </svg>
                <?php endif; ?>
                <div class="card-body text-center">
                    <h3 class="card-title"><a href="/informasi/<?php echo e($posts[0]->slug); ?>"
                            class="text-decoration-none text-dark"><?php echo e($posts[0]->title); ?></a></h3>
                    <p>
                        <small class="text-muted">
                            Oleh: <?php echo e($posts[0]->author->name); ?>

                            <?php echo e($posts[0]->created_at->diffForHumans()); ?>

                        </small>
                    </p>
                    <p class="card-text"><?php echo e($posts[0]->excerpt); ?></p>
                    <a href="/informasi/<?php echo e($posts[0]->slug); ?>" class="text-decoration-none btn btn-success">Baca
                        selengkapnya...</a>
                </div>
            </div>

            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $posts->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-3">
                            <div class="card">
                                <div class="position-absolute px-3 py-2" style="background-color: rgba(0, 0, 0, 0.7)"><a
                                        href="/informasi/<?php echo e($post->slug); ?>"
                                        class="text-white text-decoration-none"><?php echo e($post->category->name); ?></a></div>
                                <?php if($post->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $post->image)); ?>"
                                        alt="<?php echo e($post->category->name); ?>" class="img-fluid">
                                <?php else: ?>
                                    <img src="https://source.unsplash.com/500x400?<?php echo e($post->category->name); ?>"
                                        class="card-img-top" alt="<?php echo e($post->category->name); ?>">
                                <?php endif; ?>
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($post->title); ?></h5>
                                    <p>
                                        <small class="text-muted">
                                            Oleh: <?php echo e($post->author->name); ?>

                                            <?php echo e($post->created_at->diffForHumans()); ?>

                                        </small>
                                    </p>
                                    <p class="card-text"><?php echo e($post->excerpt); ?></p>
                                    <a href="/informasi/<?php echo e($post->slug); ?>" class="btn btn-success">Baca
                                        selengkapnya...</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php else: ?>
            <p class="text-center fs-4">Tidak ada <?php echo e($title); ?> yang ditemukan.</p>
        <?php endif; ?>

        <div class="d-flex justify-content-center mt-5">
            <?php echo e($posts->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Guest.Layouts.Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 6\PROJECT_GALING\web_profile_desa\resources\views/Guest/Posts.blade.php ENDPATH**/ ?>